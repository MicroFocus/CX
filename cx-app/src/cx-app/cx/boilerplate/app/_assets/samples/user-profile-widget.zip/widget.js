(function (window, undefined) {
    "use strict";

    /**
     * The base angular module.  Here you name the module you are creating.  Any dependencies must be declared.
     *
     * @ngdoc module
     * @name B27F0520-86CF-1033-B9C8-005056A891FF
     * @summary
     * To ensure that the widget is unique, we name the module and widget as UUID, thereby giving widget
     *  a uinique identifier when we define the dashboard provider.
     */
    angular.module("B27F0520-86CF-1033-B9C8-005056A891FF", ["app.core"])
        .config(["dashboardProvider", function (dashboardProvider) {
            dashboardProvider
                .widget("B27F0520-86CF-1033-B9C8-005056A891FF", {
                    title: "User Profile",
                    description: "This widget displays current user information.",
                    templateUrl: "/dashboardplugins/B27F0520-86CF-1033-B9C8-005056A891FF/widget.html",
                    controller: "widgetCtrl",
                    edit: {
                        templateUrl: "/dashboardplugins/B27F0520-86CF-1033-B9C8-005056A891FF/widget.html",
                        controller: "widgetCtrl"
                    }
                });
        }])
        /**
        * @ngdoc service
        * @name widgetService
        * @param {Object} logger
        * @param {Object} $http
        * @summary
        * widgetService is responsible to return the data from the http request made to the api URL
        */
        .service("widgetService", ["logger", "$http", function (logger, $http) {
            var vm = this;
            var widgetURL = "/SentinelRESTServices/objects/user/_CURRENT_";
            var widgetData = [];
            logger.dev("user profile Service started");
            /**
             * Returns current user data
             *
             * @name getData
             */
            vm.getData = function () {
                return $http({
                    method: "GET",
                    url: widgetURL
                }).then(function (response) {
                    return response.data;
                });
            };
        }])
        /**
         * @ngdoc controller
         * @name widgetCtrl
         * @param {Function} logger
         * @param {Function} $http
         * @param {Function} widgetService
         * @param {Function} localizationService
         * @constructor
         */
        .controller("widgetCtrl", ["logger", "$scope", "$http", "widgetService", "localizationService",
          function (logger, $scope, $http, widgetService, localizationService) {
            var myuid;
            var myrole;
            var locale = localizationService.getLocale();

            localizationService.loadTranslation("/dashboardplugins/B27F0520-86CF-1033-B9C8-005056A891FF/" +
                "resources-locale_xh.json");
            logger.info("user profile WidgetContoller started");
            $scope.gridOptions = {};
            /**
             * load function
             *
             */
            $scope.load = function () {
                widgetService.getData().then(function (response) {
                    $scope.mydata = response;
                    $scope.myrole = response.roles[0].split("/").pop();
                    $scope.myuid = response.meta["@href"].split("/").pop();
                    $scope.state = response.state;
                    $scope.uname = response.name;

                });
            };
            $scope.load();

        }]);
})(window);

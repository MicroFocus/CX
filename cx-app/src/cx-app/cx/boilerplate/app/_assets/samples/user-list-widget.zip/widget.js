(function () {
    "use strict";

    /**
     * The base angular module.  Here you name the module you are creating.  Any dependencies must be declared.
     *
     * @ngdoc module
     * @name B27F0520-86CF-1033-B9C8-005056A891CC
     * @requires adf.provider - The Module that you will use to register the widget.
     * @requires gettext- for localising the strings
     * @summary
     * To ensure that the widget is unique, we name the module and widget as UUID, thereby giving widget
     *  a uinique identifier when we define the dashboard provider.
     */
    angular.module("B27F0520-86CF-1033-B9C8-005056A891CC", ["app.core", "ui.grid"])
        .config(["dashboardProvider", function (dashboardProvider) {
            dashboardProvider
                .widget("B27F0520-86CF-1033-B9C8-005056A891CC", {
                    title: "User List",
                    description: "This widget displays user list.",
                    templateUrl: "/dashboardplugins/B27F0520-86CF-1033-B9C8-005056A891CC/widget.html",
                    controller: "userlistController",
                    edit: {
                        templateUrl: "/dashboardplugins/B27F0520-86CF-1033-B9C8-005056A891CC/widget.html",
                        controller: "userlistController"
                    }
                });
        }])
        /**
        * @ngdoc service
        * @name userlistService
        * @summary
        * userlistService is responsible to return the data from the http request made to the api URL
        * @param {Object} logger
        * @param {Object} $http
        */
        .service("userlistService", ["logger", "$http", function (logger, $http) {
            var vm = this;
            var widgetURL = "/SentinelRESTServices/objects/user";
            var widgetData = [];
            logger.dev("userlistService started");
            /**
             * Returns current user data
             *
             * @name getData
             */
            vm.getData = function () {
                return $http({
                    method: "GET",
                    url: widgetURL
                }).then(function (response) {
                    return response.data;
                });
            };
        }])
        /**
         * @ngdoc controller
         * @name userlistController
         * @memberof Widget
         * @summary
         *  The controller uses the data returned from the api and pushes it into a new row of the table grid.
         *
         * @param {Function} logger
         * @param {Function} $http
         * @param {Function} userlistService
         * @param {Function} localizationService
         *
         */
        .controller("userlistController", ["logger", "$scope", "$http", "userlistService", "localizationService",
            function (logger, $scope, $http, userlistService, localizationService) {
                var locale = localizationService.getLocale();
                localizationService.loadTranslation("/dashboardplugins/B27F0520-86CF-1033-B9C8-005056A891CC/" +
                "resources-locale_{{locale}}.json");
                logger.info("user list Contoller started");
                $scope.gridOptions = {};
                $scope.gridOptions.data = [];
                $scope.columnDefs = [{name: localizationService.getString("Users"), field: "name"}];
                /**
                 * load function
                 *
                 */
                $scope.load = function () {
                    userlistService.getData().then(function (response) {
                        response.objects.forEach(function (response) {
                            $scope.gridOptions.columnDefs = $scope.columnDefs;
                            $scope.gridOptions.data.push({name: response.name});
                            logger.info(response.name);
                        });
                    });
                };

                $scope.load();
            }
        ]);
})();
